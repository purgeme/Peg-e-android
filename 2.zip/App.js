import React from 'react';
import Navigation from "./app/screens/Navigator"

// const App = () => {
//   return (
//     <NavigationContainer>
//       {/* Rest of your app code */}
//     </NavigationContainer>
//   );
// };

// export default App;

export default function App() {
  return <Navigation />;
}