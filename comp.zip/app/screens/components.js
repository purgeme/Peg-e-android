
export default class Point {
    constructor(){
        this.x = 0;
        this.y = 0;
    }
}