import React, { Component } from 'react';
import { ImageBackground, StyleSheet, View, Image, Text, Button, Pressable, PanResponder } from 'react-native';
import { diff } from 'react-native-reanimated';

// import Point from './components'

class Point {
    constructor(){
        var x = 0;
        var y = 0;
    }
}

class Puzzle extends Component{

    constructor(){
        super();
        this.direction_s = [
            { x: 0, y: 1},
            { x: 1, y: 1},
            { x: 1, y: 0},
            { x: 1, y: -1},
            { x: 0, y: -1},
            { x: -1, y: -1},
            { x: -1, y: 0},
            { x: -1, y: 1},
        ];
    }

    // state.direction = [
    //         { x: 0, y: 1},
    //         { x: 1, y: 1},
    //         { x: 1, y: 0},
    //         { x: 1, y: -1},
    //         { x: 0, y: -1},
    //         { x: -1, y: -1},
    //         { x: -1, y: 0},
    //         { x: -1, y: 1},
    //     ];

    shuffleArray(array) {
      let curId = array.length;
      // There remain elements to shuffle
      while (0 !== curId) {
        // Pick a remaining element
        let randId = Math.floor(Math.random() * curId);
        curId -= 1;
        // Swap it with the current element.
        let tmp = array[curId];
        array[curId] = array[randId];
        array[randId] = tmp;
      }
      return array;
    }

    findNextMove(start_hole, jumped_hole, end_hole){
        this.shuffleArray(this.direction_s)
        for( let i in this.direction_s){
            var direction = this.direction_s[i];
            var a1 = new Point();
            a1.x = direction.x + start_hole.x;
            a1.y = direction.y + start_hole.y;
            jumped_hole = a1
            // jumped_hole.x = direction.x + start_hole.x;
            // jumped_hole.y = direction.y + start_hole.y;
            return true;
        }
    }

    findMoves(start, loops) {
      var pegs = [];
      pegs.push(start);

      var jumped_hole = new Point();
      // jumped_hole.x = 3;
      var end_hole = new Point();
      // var jumped_hole = [0, 0];
      // var end_hole = [0, 0];
      this.findNextMove(1, 2, 3)
      for (let i = 0; i < loops; i++) {
          this.shuffleArray(pegs)
          for(let u in pegs){
              if(this.findNextMove(pegs[u], jumped_hole, end_hole)){
                console.log("Found next move!!!")
              }
              break;
          }
      }
    }

    generate(seed, difficulty){
      var startx = Math.random()
      var starty = Math.random()
      difficulty += 5
      var pegs = difficulty
      var start = new Point();
      this.findMoves(start, 2)
    }
}

export default Puzzle;