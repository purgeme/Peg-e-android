import React, { Component } from 'react';
import { ImageBackground, StyleSheet, View, Image, Text, Button, Pressable, PanResponder } from 'react-native';
import { State, TouchableOpacity } from 'react-native-gesture-handler';
import Animated from 'react-native-reanimated';

// The actual holes that the grid is made of

class CircleButton extends Component{
  state = {
    isHole: this.props.isHole,
    hasPeg: this.props.hasPeg,
  };

  render() {
  const {isHole, hasPeg} = this.state;
  return(
    <Pressable onPress={ () => this.setState({hasPeg:!hasPeg})}>
        <View style={ isHole?hasPeg?styles.PurpleCircle:styles.WhiteCircle:styles.DarkCircle } />
    </Pressable>
  )
  }
}

const styles = StyleSheet.create({
    PurpleCircle: {
      //To make Circle Shape
      width: 150,
      height: 150,
      borderRadius: 150 / 2,
      backgroundColor: '#FF00FF',
    },
    WhiteCircle: {
      //To make Circle Shape
      width: 150,
      height: 150,
      borderRadius: 150 / 2,
      backgroundColor: '#ffffff',
    },
    DarkCircle: {
      //To make Circle Shape
      width: 150,
      height: 150,
      borderRadius: 150 / 2,
      backgroundColor: '#282a36',
    },
})

export default CircleButton;