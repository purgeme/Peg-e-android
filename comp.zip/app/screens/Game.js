import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { ImageBackground, StyleSheet, View, Image, Text, Button, Pressable } from 'react-native';

import CircleButton from './circle_button';
import Puzzle from './puzzle';
import Point from './components';

const GameScreen = ({ navigation, route }) => {

  var size = 4
  var holes = [size][size];
  var pegs = [size][size];
  // These values are going to be modified by an algorithm later on
  holes = [
    [1, 1, 0, 0],
    [0, 1, 1, 0],
    [1, 1, 0, 0],
    [1, 0, 0, 0],
  ]
  pegs = [
    [1, 0, 0, 0],
    [0, 1, 1, 0],
    [0, 0, 0, 0],
    [1, 0, 0, 0],
  ]

  var x = new Puzzle
  x.generate(10, 5)

  // Dynamically render the grid
  var collist = [];
  for(let i=0; i < size; i++){
    var rowlist = [];
    for(let t=0; t < size; t++){
      rowlist.push(
        <CircleButton isHole={holes[i][t]} hasPeg={pegs[i][t]} key={t} />
      )
    }
    collist.push(
      <View style={styles.Row} key={i}>
        {rowlist}
      </View>
    )
  }

  return (
    <View style={styles.background}>
      {collist}
    </View>
    );
};

const styles = StyleSheet.create({
    background: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: '#282a36',
    },
    Column: {
      flexDirection: "column",
    },
    Row: {
      flexDirection: "row",
    },
})


// Hide the navbar
// {{{
GameScreen.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired,
  }).isRequired,
};
GameScreen.navigationOptions = {
  headerShown: false,
};
// }}}

export default GameScreen;